#!/bin/sh -ex

docker pull yuzuemu/build-environments:linux-fresh
