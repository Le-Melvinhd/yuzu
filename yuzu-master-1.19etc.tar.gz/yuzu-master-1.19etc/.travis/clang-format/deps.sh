#!/bin/sh -ex

docker pull citraemu/build-environments:linux-clang-format
