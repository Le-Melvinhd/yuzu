JSON for Modern C++
===================

v3.1.2

This is a mirror providing the single required header file.

The original repository can be found at:
https://github.com/nlohmann/json/commit/d2dd27dc3b8472dbaa7d66f83619b3ebcd9185fe
