From https://github.com/corporateshark/LUrlParser/commit/455d5e2d27e3946f11ad0328fee9ee2628e6a8e2

MIT License

===

Lightweight URL & URI parser (RFC 1738, RFC 3986)

(C) Sergey Kosarevsky, 2015

@corporateshark sk@linderdaum.com

http://www.linderdaum.com

http://blog.linderdaum.com

=============================

A tiny and lightweight URL & URI parser (RFC 1738, RFC 3986) written in C++.
