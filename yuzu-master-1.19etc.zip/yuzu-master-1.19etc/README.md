# yuzu-master-archive
 FUCK YOU NINTENDO! THIS IS BACK

For those who are uninformed, Yuzu was taken down by Nintendo. I am not affiliated with the Yuzu team but I do believe in standing up to bullies. I found this source code on Archive.org and was able to bring it back. I will also publish the installer for the windows release. Feel free to continue development because I AM NOT talented enough to continue development on my own.



NOTE TO NINTENDO:
THIS IS BY NO MEANS ENDORSES PIRACY BUT IF PEOPLE DO USE IT FOR SUCH, THAT'S ON THEM. YOU CHARGE EXTORTION PRICES FOR INFINATELY REPLICABLE CODE AND EXPECT PEOPLE TO PAY FOR SOMETHING THEY DON'T OWN. SO TO THE NINTENDO LAWYERS READING THIS, YOU CAN SHOVE THE LAWSUIT WHERE THE SUN DON'T SHINE. MARIO WOULD LOVE IT IF YOU DIDN'T USE LUBE!
