#!/bin/bash -ex

# Run clang-format
cd /yuzu
./.travis/clang-format/script.sh
