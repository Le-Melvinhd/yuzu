git config --global user.email "yuzu@yuzu-emu.org"
git config --global user.name "yuzubot"