// Copyright 2018 Citra Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

#include "common/memory_hook.h"

namespace Common {

MemoryHook::~MemoryHook() = default;

} // namespace Common
